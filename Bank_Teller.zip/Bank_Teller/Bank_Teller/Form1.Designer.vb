﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.picLogo = New System.Windows.Forms.PictureBox()
        Me.lblAccountNumber = New System.Windows.Forms.Label()
        Me.mskAccountNumber = New System.Windows.Forms.MaskedTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnFind = New System.Windows.Forms.Button()
        Me.lblAccountName = New System.Windows.Forms.Label()
        Me.grpSelectAction = New System.Windows.Forms.GroupBox()
        Me.numAmount = New System.Windows.Forms.NumericUpDown()
        Me.lblAmount = New System.Windows.Forms.Label()
        Me.btnWithdraw = New System.Windows.Forms.Button()
        Me.btnDeposit = New System.Windows.Forms.Button()
        Me.lbl = New System.Windows.Forms.Label()
        Me.lblBalance = New System.Windows.Forms.Label()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.picLogo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpSelectAction.SuspendLayout()
        CType(Me.numAmount, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picLogo
        '
        Me.picLogo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.picLogo.ErrorImage = Global.Bank_Teller.My.Resources.Resources.bank
        Me.picLogo.Image = Global.Bank_Teller.My.Resources.Resources.bank
        Me.picLogo.Location = New System.Drawing.Point(13, 13)
        Me.picLogo.Name = "picLogo"
        Me.picLogo.Size = New System.Drawing.Size(135, 120)
        Me.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picLogo.TabIndex = 0
        Me.picLogo.TabStop = False
        '
        'lblAccountNumber
        '
        Me.lblAccountNumber.AutoSize = True
        Me.lblAccountNumber.Location = New System.Drawing.Point(154, 15)
        Me.lblAccountNumber.Name = "lblAccountNumber"
        Me.lblAccountNumber.Size = New System.Drawing.Size(90, 13)
        Me.lblAccountNumber.TabIndex = 1
        Me.lblAccountNumber.Text = "Account Number:"
        '
        'mskAccountNumber
        '
        Me.mskAccountNumber.Location = New System.Drawing.Point(250, 12)
        Me.mskAccountNumber.Mask = "00000"
        Me.mskAccountNumber.Name = "mskAccountNumber"
        Me.mskAccountNumber.PromptChar = Global.Microsoft.VisualBasic.ChrW(32)
        Me.mskAccountNumber.Size = New System.Drawing.Size(48, 20)
        Me.mskAccountNumber.TabIndex = 2
        Me.mskAccountNumber.ValidatingType = GetType(Integer)
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(154, 50)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(118, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Account Holder Name: "
        '
        'btnFind
        '
        Me.btnFind.Location = New System.Drawing.Point(304, 12)
        Me.btnFind.Name = "btnFind"
        Me.btnFind.Size = New System.Drawing.Size(61, 23)
        Me.btnFind.TabIndex = 3
        Me.btnFind.Text = "Find"
        Me.btnFind.UseVisualStyleBackColor = True
        '
        'lblAccountName
        '
        Me.lblAccountName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAccountName.Location = New System.Drawing.Point(157, 73)
        Me.lblAccountName.Name = "lblAccountName"
        Me.lblAccountName.Size = New System.Drawing.Size(115, 20)
        Me.lblAccountName.TabIndex = 5
        '
        'grpSelectAction
        '
        Me.grpSelectAction.Controls.Add(Me.numAmount)
        Me.grpSelectAction.Controls.Add(Me.lblAmount)
        Me.grpSelectAction.Controls.Add(Me.btnWithdraw)
        Me.grpSelectAction.Controls.Add(Me.btnDeposit)
        Me.grpSelectAction.Location = New System.Drawing.Point(13, 140)
        Me.grpSelectAction.Name = "grpSelectAction"
        Me.grpSelectAction.Size = New System.Drawing.Size(260, 83)
        Me.grpSelectAction.TabIndex = 7
        Me.grpSelectAction.TabStop = False
        Me.grpSelectAction.Text = "Select An Action:"
        '
        'numAmount
        '
        Me.numAmount.DecimalPlaces = 2
        Me.numAmount.Increment = New Decimal(New Integer() {1, 0, 0, 131072})
        Me.numAmount.Location = New System.Drawing.Point(160, 38)
        Me.numAmount.Maximum = New Decimal(New Integer() {100000, 0, 0, 0})
        Me.numAmount.Minimum = New Decimal(New Integer() {1, 0, 0, -2147483648})
        Me.numAmount.Name = "numAmount"
        Me.numAmount.Size = New System.Drawing.Size(70, 20)
        Me.numAmount.TabIndex = 7
        '
        'lblAmount
        '
        Me.lblAmount.Location = New System.Drawing.Point(104, 40)
        Me.lblAmount.Name = "lblAmount"
        Me.lblAmount.Size = New System.Drawing.Size(50, 15)
        Me.lblAmount.TabIndex = 6
        Me.lblAmount.Text = "Amount:"
        '
        'btnWithdraw
        '
        Me.btnWithdraw.Enabled = False
        Me.btnWithdraw.Location = New System.Drawing.Point(7, 50)
        Me.btnWithdraw.Name = "btnWithdraw"
        Me.btnWithdraw.Size = New System.Drawing.Size(75, 25)
        Me.btnWithdraw.TabIndex = 9
        Me.btnWithdraw.Text = "Withdraw"
        Me.btnWithdraw.UseVisualStyleBackColor = True
        '
        'btnDeposit
        '
        Me.btnDeposit.Enabled = False
        Me.btnDeposit.Location = New System.Drawing.Point(7, 20)
        Me.btnDeposit.Name = "btnDeposit"
        Me.btnDeposit.Size = New System.Drawing.Size(75, 25)
        Me.btnDeposit.TabIndex = 8
        Me.btnDeposit.Text = "Deposit"
        Me.btnDeposit.UseVisualStyleBackColor = True
        '
        'lbl
        '
        Me.lbl.AutoSize = True
        Me.lbl.Location = New System.Drawing.Point(343, 140)
        Me.lbl.Name = "lbl"
        Me.lbl.Size = New System.Drawing.Size(49, 13)
        Me.lbl.TabIndex = 10
        Me.lbl.Text = "Balance:"
        '
        'lblBalance
        '
        Me.lblBalance.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblBalance.Location = New System.Drawing.Point(317, 160)
        Me.lblBalance.Name = "lblBalance"
        Me.lblBalance.Size = New System.Drawing.Size(100, 16)
        Me.lblBalance.TabIndex = 11
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(346, 192)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(46, 23)
        Me.btnClose.TabIndex = 12
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(157, 111)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(115, 23)
        Me.Button1.TabIndex = 13
        Me.Button1.Text = "Transaction History"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(444, 241)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.lblBalance)
        Me.Controls.Add(Me.lbl)
        Me.Controls.Add(Me.grpSelectAction)
        Me.Controls.Add(Me.lblAccountName)
        Me.Controls.Add(Me.btnFind)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.mskAccountNumber)
        Me.Controls.Add(Me.lblAccountNumber)
        Me.Controls.Add(Me.picLogo)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "MainForm"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Text = "Bank Teller "
        CType(Me.picLogo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpSelectAction.ResumeLayout(False)
        CType(Me.numAmount, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents picLogo As PictureBox
    Friend WithEvents lblAccountNumber As Label
    Friend WithEvents mskAccountNumber As MaskedTextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnFind As Button
    Friend WithEvents lblAccountName As Label
    Friend WithEvents grpSelectAction As GroupBox
    Friend WithEvents lblAmount As Label
    Friend WithEvents btnWithdraw As Button
    Friend WithEvents btnDeposit As Button
    Friend WithEvents lbl As Label
    Friend WithEvents lblBalance As Label
    Friend WithEvents btnClose As Button
    Friend WithEvents numAmount As NumericUpDown
    Friend WithEvents Button1 As Button
End Class
