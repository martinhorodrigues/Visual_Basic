﻿Public Class TransactionLog
    Private Sub TransactionLog_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        'ListBox is clear for next Transaction log to be displayed, safeguards repeat of display data'
        lsbTransactionLog.Items.Clear()
        Me.Close()
    End Sub
End Class