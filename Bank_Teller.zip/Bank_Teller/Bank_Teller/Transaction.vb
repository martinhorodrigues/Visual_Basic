﻿Public Class Transaction
    'List of variables needed for the Transaction object'
    Public Property accountNumber As String
    Public Property TransactionDateTime As Date
    Public Property amount As Decimal
    Public Property balance As Decimal
    'A overridden ToString function to help format all the data to be displayed in the ListBox
    Public Overrides Function ToString() As String
        Return CStr(accountNumber & ", " & TransactionDateTime & ", $" & amount & ", $" & balance & ".")
    End Function
    'The constructor for the Transaction class
    Public Sub New(ByVal a As String, ByVal b As Date, ByVal c As Decimal, ByVal d As Decimal)
        accountNumber = a
        TransactionDateTime = b
        amount = c
        balance = d
    End Sub
End Class
