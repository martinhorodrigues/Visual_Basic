﻿
Public Class MainForm
    Dim transactions As New ArrayList()
    Private currAccount As Account
    Private transaction As Transaction 'Object Transaction for user'
    Private ReadOnly FILEPATH As String = "..\..\accounts.txt"
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnFind_Click(sender As Object, e As EventArgs) Handles btnFind.Click
        currAccount = New Account(mskAccountNumber.Text) 'assigns values to Account object'
        currAccount.FilePath = FILEPATH 'assigns the file to be used in this program'
        If currAccount.GetData() Then 'If the process proves true, then....'
            lblAccountName.Text = currAccount.AccountName
            lblBalance.Text = currAccount.Balance.ToString("c")
            btnDeposit.Enabled = True
            btnWithdraw.Enabled = True
            'transaction.accountNumber = CStr(mskAccountNumber.Text) This needs to be removed'
        Else 'if an error occurs, a messagebox will show itself to the user'
            MessageBox.Show(currAccount.LastError, "Error")
            Clear()
        End If
    End Sub
    Private Sub Clear() 'Clears all the information for the user.'
        lblAccountName.Text = String.Empty
        lblBalance.Text = String.Empty
        btnDeposit.Enabled = False
        btnWithdraw.Enabled = False

    End Sub

    Private Sub btnDeposit_Click(sender As Object, e As EventArgs) Handles btnDeposit.Click 'Deposits the amount to the balance and assigns values to the transaction object
        Try
            If currAccount.Deposit(CDec(numAmount.Value)) Then
                lblBalance.Text = currAccount.Balance.ToString("c")
                Dim depTransaction As Transaction = New Transaction(CStr(lblAccountNumber.Text), DateTime.Now, Math.Round(numAmount.Value, 2), Math.Round(currAccount.Balance, 2))
                transactions.Add(depTransaction)
            Else
                MessageBox.Show(currAccount.LastError, "Error")
            End If
        Catch
            MessageBox.Show("Please enter a numeric deposit amount that is greater than zero(0).", "Error")
        End Try
    End Sub

    Private Sub btnWithdraw_Click(sender As Object, e As EventArgs) Handles btnWithdraw.Click
        Try
            If currAccount.Withdraw(CDec(numAmount.Value)) Then
                lblBalance.Text = currAccount.Balance.ToString("c")
                Dim withTransaction As Transaction = New Transaction(CStr(lblAccountNumber.Text), DateTime.Now, Decimal.Negate(numAmount.Value), Math.Round(currAccount.Balance, 2))
                transactions.Add(withTransaction)
            Else
                MessageBox.Show(currAccount.LastError, "Error")
            End If
        Catch
            MessageBox.Show("Please enter a numeric withdraw amount that is greater than zero(0)", "Error")
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'MessageBox.Show("For this account, the total of withdraws is $" + (currAccount.TotalWithdraws).ToString +
        ' " And the total of deposits is $" + (currAccount.TotalDeposits).ToString + ".", "Informational")
        For Each i In transactions
            TransactionLog.lsbTransactionLog.Items.Add(i.ToString())
        Next
        TransactionLog.Show()
    End Sub
    Private Sub mskAccountNumber_Click(sender As Object, e As EventArgs) Handles mskAccountNumber.Click
        mskAccountNumber.SelectAll()
    End Sub
End Class
