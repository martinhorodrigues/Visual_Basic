﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.label11 = New System.Windows.Forms.Label()
        Me.label10 = New System.Windows.Forms.Label()
        Me.label9 = New System.Windows.Forms.Label()
        Me.label8 = New System.Windows.Forms.Label()
        Me.button2 = New System.Windows.Forms.Button()
        Me.button1 = New System.Windows.Forms.Button()
        Me.label7 = New System.Windows.Forms.Label()
        Me.label6 = New System.Windows.Forms.Label()
        Me.label5 = New System.Windows.Forms.Label()
        Me.label4 = New System.Windows.Forms.Label()
        Me.label3 = New System.Windows.Forms.Label()
        Me.checkBox2 = New System.Windows.Forms.CheckBox()
        Me.checkBox1 = New System.Windows.Forms.CheckBox()
        Me.comboBox1 = New System.Windows.Forms.ComboBox()
        Me.label2 = New System.Windows.Forms.Label()
        Me.lnkWeather = New System.Windows.Forms.LinkLabel()
        Me.clbEquipment = New System.Windows.Forms.CheckedListBox()
        Me.lblEquip = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'label11
        '
        Me.label11.AutoSize = True
        Me.label11.Location = New System.Drawing.Point(424, 137)
        Me.label11.Name = "label11"
        Me.label11.Size = New System.Drawing.Size(41, 13)
        Me.label11.TabIndex = 35
        Me.label11.Text = "label11"
        '
        'label10
        '
        Me.label10.AutoSize = True
        Me.label10.Location = New System.Drawing.Point(424, 102)
        Me.label10.Name = "label10"
        Me.label10.Size = New System.Drawing.Size(41, 13)
        Me.label10.TabIndex = 34
        Me.label10.Text = "label10"
        '
        'label9
        '
        Me.label9.AutoSize = True
        Me.label9.Location = New System.Drawing.Point(424, 70)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(35, 13)
        Me.label9.TabIndex = 33
        Me.label9.Text = "label9"
        '
        'label8
        '
        Me.label8.AutoSize = True
        Me.label8.Location = New System.Drawing.Point(424, 34)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(35, 13)
        Me.label8.TabIndex = 32
        Me.label8.Text = "label8"
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(322, 163)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(75, 23)
        Me.button2.TabIndex = 31
        Me.button2.Text = "Close"
        Me.button2.UseVisualStyleBackColor = True
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(205, 163)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(75, 23)
        Me.button1.TabIndex = 30
        Me.button1.Text = "Calculate"
        Me.button1.UseVisualStyleBackColor = True
        Me.button1.Visible = False
        '
        'label7
        '
        Me.label7.AutoSize = True
        Me.label7.Location = New System.Drawing.Point(375, 134)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(35, 13)
        Me.label7.TabIndex = 29
        Me.label7.Text = "label7"
        '
        'label6
        '
        Me.label6.AutoSize = True
        Me.label6.Location = New System.Drawing.Point(375, 34)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(35, 13)
        Me.label6.TabIndex = 28
        Me.label6.Text = "label6"
        '
        'label5
        '
        Me.label5.AutoSize = True
        Me.label5.Location = New System.Drawing.Point(375, 102)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(35, 13)
        Me.label5.TabIndex = 27
        Me.label5.Text = "label5"
        '
        'label4
        '
        Me.label4.AutoSize = True
        Me.label4.Location = New System.Drawing.Point(375, 70)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(35, 13)
        Me.label4.TabIndex = 26
        Me.label4.Text = "label4"
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Location = New System.Drawing.Point(424, 5)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(35, 13)
        Me.label3.TabIndex = 25
        Me.label3.Text = "label3"
        '
        'checkBox2
        '
        Me.checkBox2.AutoSize = True
        Me.checkBox2.Location = New System.Drawing.Point(205, 117)
        Me.checkBox2.Name = "checkBox2"
        Me.checkBox2.Size = New System.Drawing.Size(97, 17)
        Me.checkBox2.TabIndex = 24
        Me.checkBox2.Text = "Liability Waiver"
        Me.checkBox2.UseVisualStyleBackColor = True
        '
        'checkBox1
        '
        Me.checkBox1.AutoSize = True
        Me.checkBox1.Location = New System.Drawing.Point(205, 66)
        Me.checkBox1.Name = "checkBox1"
        Me.checkBox1.Size = New System.Drawing.Size(116, 17)
        Me.checkBox1.TabIndex = 23
        Me.checkBox1.Text = "Damage Insurance"
        Me.checkBox1.UseVisualStyleBackColor = True
        '
        'comboBox1
        '
        Me.comboBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboBox1.FormattingEnabled = True
        Me.comboBox1.Items.AddRange(New Object() {"One(1) Day", "Two(2) Day", "Three(3) Day", "One(1) Week", "Two(2) Week"})
        Me.comboBox1.Location = New System.Drawing.Point(205, 25)
        Me.comboBox1.MaxDropDownItems = 6
        Me.comboBox1.Name = "comboBox1"
        Me.comboBox1.Size = New System.Drawing.Size(120, 21)
        Me.comboBox1.TabIndex = 22
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(222, 9)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(81, 13)
        Me.label2.TabIndex = 21
        Me.label2.Text = "Rental Duration"
        '
        'lnkWeather
        '
        Me.lnkWeather.Cursor = System.Windows.Forms.Cursors.Hand
        Me.lnkWeather.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline
        Me.lnkWeather.Location = New System.Drawing.Point(52, 168)
        Me.lnkWeather.Name = "lnkWeather"
        Me.lnkWeather.Size = New System.Drawing.Size(95, 15)
        Me.lnkWeather.TabIndex = 6
        Me.lnkWeather.TabStop = True
        Me.lnkWeather.Text = "&Weather Forecast"
        Me.lnkWeather.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'clbEquipment
        '
        Me.clbEquipment.CheckOnClick = True
        Me.clbEquipment.Cursor = System.Windows.Forms.Cursors.Hand
        Me.clbEquipment.FormattingEnabled = True
        Me.clbEquipment.Items.AddRange(New Object() {"Skis, beginner", "Skis, advanced", "Snowboard, beginner", "Snowboard, advanced", "Ski Boots", "Snowboard boots", "Helmet, standard", "Helmet, deluxe"})
        Me.clbEquipment.Location = New System.Drawing.Point(31, 34)
        Me.clbEquipment.Name = "clbEquipment"
        Me.clbEquipment.Size = New System.Drawing.Size(135, 124)
        Me.clbEquipment.TabIndex = 1
        '
        'lblEquip
        '
        Me.lblEquip.Location = New System.Drawing.Point(12, 9)
        Me.lblEquip.Name = "lblEquip"
        Me.lblEquip.Size = New System.Drawing.Size(170, 15)
        Me.lblEquip.TabIndex = 18
        Me.lblEquip.Text = "&Select all Equipment to be Rented"
        Me.lblEquip.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(490, 248)
        Me.Controls.Add(Me.label11)
        Me.Controls.Add(Me.label10)
        Me.Controls.Add(Me.label9)
        Me.Controls.Add(Me.label8)
        Me.Controls.Add(Me.button2)
        Me.Controls.Add(Me.button1)
        Me.Controls.Add(Me.label7)
        Me.Controls.Add(Me.label6)
        Me.Controls.Add(Me.label5)
        Me.Controls.Add(Me.label4)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.checkBox2)
        Me.Controls.Add(Me.checkBox1)
        Me.Controls.Add(Me.comboBox1)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.lnkWeather)
        Me.Controls.Add(Me.clbEquipment)
        Me.Controls.Add(Me.lblEquip)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Private WithEvents label11 As Label
    Private WithEvents label10 As Label
    Private WithEvents label9 As Label
    Private WithEvents label8 As Label
    Private WithEvents button2 As Button
    Private WithEvents button1 As Button
    Private WithEvents label7 As Label
    Private WithEvents label6 As Label
    Private WithEvents label5 As Label
    Private WithEvents label4 As Label
    Private WithEvents label3 As Label
    Private WithEvents checkBox2 As CheckBox
    Private WithEvents checkBox1 As CheckBox
    Private WithEvents comboBox1 As ComboBox
    Private WithEvents label2 As Label
    Private WithEvents lnkWeather As LinkLabel
    Private WithEvents clbEquipment As CheckedListBox
    Private WithEvents lblEquip As Label
End Class
