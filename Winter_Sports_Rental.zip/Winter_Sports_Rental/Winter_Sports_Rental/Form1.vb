﻿Public Class Form1
    Private Sub lnkWeather_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles lnkWeather.LinkClicked

    End Sub
End Class
