﻿Imports System.IO                 ' StreamReader class
Imports System.IO.File          ' OpenText method

Public Class Account
    'list of variables needed for the Account Class
    Private mBalance As Decimal

    Public Property AccountId As String
    Public Property AccountName As String
    Public Property FilePath As String
    Public Property LastError As String
    Public Property TotalDeposits As String
    Public Property TotalWithdraws As String
    'Get function for the mBalance variable
    Public ReadOnly Property Balance As Decimal
        Get
            Return mBalance
        End Get
    End Property

    Public Sub New(ByVal pAccountId As String)
        ' Create a new account, using an account ID
        AccountId = pAccountId
        AccountName = String.Empty
        mBalance = 0D
        _TotalDeposits = 0
        _TotalWithdraws = 0
    End Sub

    ' Read the data file, try to find the account ID.
    ' If found, read the account name and balance and
    ' return True. If not found, return false.
    Public Function GetData() As Boolean
        Dim infile As StreamReader = Nothing
        LastError = String.Empty 'Error message'
        Try
            infile = OpenText(FilePath)
            While Not infile.EndOfStream
                Dim entireLine As String = infile.ReadLine() 'Reads an entire line of characters
                Dim fields() As String = entireLine.Split(","c) ' Breaks line into string array; breaks on every comma
                If fields(0) = AccountId Then
                    AccountName = fields(1)
                    mBalance = CDec(fields(2))
                    Return True
                End If
            End While
            LastError = "Account " & AccountId & " not found" 'Assigns error message
            Return False
        Catch ex As Exception
            LastError = ex.Message 'assigns error message to the exception handler
            Return False
        Finally
            If infile IsNot Nothing Then infile.Close()
        End Try
        Return False
    End Function

    Public Function Deposit(ByVal amount As Decimal) As Boolean
        ' Deposit the amount in the account by adding it 
        ' to the balance.
        If amount < 0 Then
            Throw New ArgumentException("Amount must be a positive value")
            Return False
        Else
            _TotalDeposits += amount
            mBalance += amount
            Return True
        End If

    End Function

    Public Function Withdraw(ByVal amount As Decimal) As Boolean
        ' Withdraw <amount> from the account if the existing balance 
        ' is at least as large as the amount, and return True. Otherwise,
        ' return false if balance is less than <amount>.
        If amount <= mBalance And amount > 0.00 Then
            _TotalWithdraws += amount
            mBalance -= amount
            Return True
        Else
            Throw New ArgumentException("Amount is either insufficient towards your balance or is less than zero.")
            Return False
        End If
    End Function
End Class
