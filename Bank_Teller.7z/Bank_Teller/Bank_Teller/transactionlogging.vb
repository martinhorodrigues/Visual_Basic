﻿Imports System.IO                 ' StreamReader class
Imports System.IO.File
Public Class transactionlogging

    Private transactionLogArray As New List(Of Transaction)
    Private pathFile As String = "..\..\transactions.txt"
    Public ReadOnly Property Items As List(Of Transaction)
        Get
            Return transactionLogArray
        End Get
    End Property
    Public Sub Add(ByRef trans As Transaction)
        transactionLogArray.Add(trans)
    End Sub

    Public Function Save() As Boolean
        Dim infile As New StreamWriter(pathFile)
        Try
            infile = CreateText(pathFile)
            For Each i As Transaction In transactionLogArray
                infile.WriteLine(i.ToString())
            Next
            Return True
        Catch ex As Exception
            Return False
        Finally
            If infile IsNot Nothing Then infile.Close()
        End Try
    End Function
End Class
